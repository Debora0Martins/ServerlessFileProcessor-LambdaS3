import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    # Ignorar arquivos que já estão em 'processed/'
    if key.startswith("processed/"):
        print(f"Ignorando arquivo já processado: {key}")
        return

    print(f"Processando arquivo {key} do bucket {bucket_name}")

    # Novo caminho de destino
    new_key = "processed/" + key

    # Copiar o arquivo para processed/
    s3.copy_object(
        Bucket=bucket_name,
        CopySource={'Bucket': bucket_name, 'Key': key},
        Key=new_key
    )

    # Deletar o arquivo original
    s3.delete_object(Bucket=bucket_name, Key=key)

    print(f"Arquivo movido para {new_key}")

