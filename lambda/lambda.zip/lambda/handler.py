import boto3
import json

def lambda_handler(event, context):
    s3 = boto3.client('s3')

    # Pega o bucket e o arquivo do evento
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    print(f"Arquivo {key} enviado para o bucket {bucket}")

    # Copia o arquivo adicionando prefixo "processed_"
    copy_source = {'Bucket': bucket, 'Key': key}
    new_key = f"processed_{key}"
    s3.copy_object(CopySource=copy_source, Bucket=bucket, Key=new_key)

    return {
        'statusCode': 200,
        'body': json.dumps(f"Arquivo processado: {new_key}")
    }

