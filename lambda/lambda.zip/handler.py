import json
import boto3

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    print(f"Arquivo {key} enviado para o bucket {bucket}")

    copy_source = {'Bucket': bucket, 'Key': key}
    new_key = f"processed_{key}"
    s3.copy_object(CopySource=copy_source, Bucket=bucket, Key=new_key)

    return {
        'statusCode': 200,
        'body': json.dumps(f"Arquivo processado: {new_key}")
    }

